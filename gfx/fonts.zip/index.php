<?
	set_time_limit(0);
	
	function arr($a)
	{
		echo "<pre>";
		print_r($a);
		echo "</pre>";
	};
	
	function unichr($u)
	{
    return mb_convert_encoding('&#' . intval($u) . ';', 'UTF-8', 'HTML-ENTITIES');
	}
	
	$MIN_CHAR = 32;
	$MAX_CHAR = 256;
	$IMG_SIZE = 512;
	$FONT_NAME = "Roboto-Thin";
	$FONT_SIZE = 32;
	
	$im = @imagecreatetruecolor($IMG_SIZE, $IMG_SIZE);
	imagesavealpha($im, true);
	$color_alpha = imagecolorallocatealpha($im, 255, 255, 255, 127);
	$color = imagecolorallocatealpha($im, 05, 005, 05, 0);
	$color1 = imagecolorallocatealpha($im, 255, 100, 100, 0);
	$color2 = imagecolorallocatealpha($im, 100, 100, 255, 0);
	
	imagefill($im, 0, 0, $color_alpha);

	$text = "Testing...";
	$font = $FONT_NAME.".ttf";
	
	$dim[0] = $dim[1] = 1e20;
	$dim[2] = $dim[3] = -1e20;
	
	for ($i = $MIN_CHAR; $i <= $MAX_CHAR; $i++)
	{
		$text = chr($i);
		$box = imagettfbbox($FONT_SIZE, 0, $font, $text);
		$dim[0] = min($box[0], $box[4], $dim[0]); 
    $dim[1] = min($box[1], $box[5], $dim[1]); 
    $dim[2] = max($box[0], $box[4], $dim[2]); 
    $dim[3] = max($box[1], $box[5], $dim[3]); 
    
    //echo "[$text]";
    //arr($dim);
		
		//imagettftext($im, $FONT_SIZE, 0, 0, 21, $color, $font, $text);
	};
	$line_height = $dim[3] - $dim[1];
//	echo "Line height: $line_height";
	
	$x = 0;
	$y = 0;
	for ($i = $MIN_CHAR; $i <= $MAX_CHAR; $i++)
	{
		$text = chr($i);
		$box = imagettfbbox($FONT_SIZE, 0, $font, $text);
		
//		arr($box);
		
		$x_size = abs($box[4] - $box[0]) + 3;
		$y_size = abs($box[5] - $box[1]);
		
		$x_min = min($box[4], $box[0]);
		$y_min = min($box[5], $box[1]);

		if (($x + $x_size) > $IMG_SIZE)
		{
			$x = 0;
			$y += $line_height + 1;
		};
		
		if (($i % 2) == 0)
			$col = $color1;
		else
			$col = $color2;
			
		imagerectangle($im, $x, $y, $x + $x_size, $y + $line_height, $col);
		imagettftext($im, $FONT_SIZE, 0, $x - $x_min, $y - $dim[1], $color, $font, $text);
		$x += $x_size;
	};

	
//	arr($dim);
//	exit;

	header ('Content-Type: image/png');
	
	imagepng($im);
	imagepng($im, $FONT_NAME.".png");
	imagedestroy($im);
?>